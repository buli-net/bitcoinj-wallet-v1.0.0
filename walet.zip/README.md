# ₿itcoin Wallet B-Lite

B-Lite long-value display update.

## Long-value UI behavior

All single-line wallet/address/transaction/hash/key/path display fields use the shared
`wallet.ui.SelectableMiddleEllipsizedTextView` implementation where a compact display is
appropriate. The complete underlying string remains intact.

Covered UI areas include:
- Main wallet address
- Wallet selector entries (main/imported/watch-only)
- Send wallet/address and send review recipient
- Imported WIF wallet address
- Watch-only address list and watched UTXO transaction IDs
- Address book addresses
- Coin-control transaction IDs
- Transaction list counterparty and TXID
- Transaction detail sender/receiver, detail values, entries and TXID
- Receive QR address
- Backup file path
- Paper wallet address/private key display
- Sync best-chain hash and merkle root

Multi-line diagnostic/peer reports and the paper-wallet print layout intentionally keep
full text rather than applying single-line ellipsis.

Long press keeps Android's normal selectable-text action mode (`Copy`, `Share`,
`Select all`, selection handles). No custom clipboard action is used.

No wallet/sync/transaction business logic is changed by this UI update.
