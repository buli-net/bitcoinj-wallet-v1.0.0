package wallet.ui;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

/** Common native TextView behavior for long identifier-like values. */
public final class TextViewUtils {
    private static final int MIN_LONG_VALUE_LENGTH = 26;

    private TextViewUtils() {
    }

    public static void configureSelectableMiddleEllipsis(TextView view) {
        if (view == null || view instanceof EditText) return;
        view.setSingleLine(true);
        view.setMaxLines(1);
        view.setHorizontallyScrolling(false);
        view.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        view.setTextIsSelectable(true);
    }

    public static void configureLongValueViews(View root) {
        if (root == null) return;
        configureLongValueViewTree(root);
    }

    private static void configureLongValueViewTree(View view) {
        if (view instanceof EditText) return;

        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            if (isLongValue(textView.getText())) {
                configureSelectableMiddleEllipsis(textView);
            }
            return;
        }

        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                configureLongValueViewTree(group.getChildAt(i));
            }
        }
    }

    private static boolean isLongValue(CharSequence value) {
        if (value == null || value.length() < MIN_LONG_VALUE_LENGTH) return false;
        if (value.toString().indexOf('\n') >= 0) return false;

        String text = value.toString();
        String lower = text.toLowerCase(Locale.US);

        if (lower.startsWith("bc1") || lower.startsWith("tb1") || lower.startsWith("bcrt1")
                || lower.startsWith("xpub") || lower.startsWith("tpub")
                || lower.startsWith("ypub") || lower.startsWith("zpub")
                || lower.startsWith("upub") || lower.startsWith("vpub")) return true;

        if (text.startsWith("/") || text.contains("/wallet")) return true;

        boolean hex = true;
        for (int i = 0; i < text.length(); i++) {
            if (Character.digit(text.charAt(i), 16) < 0) {
                hex = false;
                break;
            }
        }
        if (hex && (text.length() == 64 || text.length() == 66)) return true;

        if (text.length() >= 26 && text.length() <= 35
                && text.matches("[1-9A-HJ-NP-Za-km-z]+")) return true;

        return !text.matches(".*\\s+.*")
                && text.matches("[1-9A-HJ-NP-Za-km-z]{26,}");
    }
}
