package wallet.ui;

import android.content.Context;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

/**
 * Long-value TextView backed entirely by Android's native middle ellipsis and
 * native text selection. It does not replace, rewrite, or redraw the text.
 * Redundant setText calls with the same value are ignored so live UI refreshes
 * cannot reset an active selection.
 */
public class SelectableMiddleEllipsizedTextView extends AppCompatTextView {

    private boolean configured;

    public SelectableMiddleEllipsizedTextView(Context context) {
        super(context);
        configureMiddleEllipsis();
    }

    public SelectableMiddleEllipsizedTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        configureMiddleEllipsis();
    }

    public SelectableMiddleEllipsizedTextView(Context context, AttributeSet attrs,
                                               int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        configureMiddleEllipsis();
    }

    /** Applies only native TextView behavior; no custom drawing or spans. */
    public void configureMiddleEllipsis() {
        if (configured) return;
        configured = true;
        setSingleLine(true);
        setMaxLines(1);
        setHorizontallyScrolling(false);
        setEllipsize(TextUtils.TruncateAt.MIDDLE);
        setTextIsSelectable(true);
        setTransformationMethod(null);
        setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE);
        setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        CharSequence current = getText();
        String newValue = text == null ? "" : text.toString();
        if (current != null && newValue.contentEquals(current)) {
            return;
        }
        super.setText(text, type);
    }
}
